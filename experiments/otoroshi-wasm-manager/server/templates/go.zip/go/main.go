package main

import (
    "github.com/extism/go-pdk"
//    "encoding/json"
    "github.com/buger/jsonparser"
)

type Backend struct {
  id string `json:"id"`
}

//export execute
func execute() int32 {
    // input := pdk.Input() 
    input := `{"id": "get"}`

    var id = jsonparser.Get(input, "id")

  

    output := `{"count":` +  id + "}"
    mem := pdk.AllocateString(output)
    pdk.OutputMemory(mem)

    return 0
}

func main() {}
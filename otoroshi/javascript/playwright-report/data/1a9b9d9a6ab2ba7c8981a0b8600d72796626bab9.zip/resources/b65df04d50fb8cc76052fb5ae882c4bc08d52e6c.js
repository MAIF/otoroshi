window.OtoroshiDarkLightMode = window.OtoroshiDarkLightMode || (function() {

    var mode = window.localStorage.getItem("otoroshi-dark-light-mode");

    var buttonSelector = "otoroshi-dark-light-icon";

    function registerClicks() {
        var button = document.getElementById(buttonSelector);
        if (button) {
            button.addEventListener('click', function(evt) {
                if (mode === "dark") {
                    mode = "light";
                } else if (mode === "light") {
                    mode = "dark";
                }
                window.localStorage.setItem("otoroshi-dark-light-mode", mode);
                fetch('/bo/api/ui-mode', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ mode: mode === "light" ? "white" : "dark" })
                })
                update();
            })
            button.parentNode.addEventListener('click', function(evt) {
                evt.preventDefault();
                evt.stopPropagation();
            })
        } else {
            setTimeout(function() {
                registerClicks();
            }, 1000);
        }
    }

    function update() {
        var button = document.getElementById(buttonSelector);
        if (button) {
            if (mode === "dark") {
                button.firstChild.classList.remove("fa-moon");
                button.firstChild.classList.remove("fa-lightbulb");
                button.firstChild.classList.add("fa-lightbulb");
                document.documentElement.setAttribute('data-theme', 'dark');
            }
            if (mode === "light") {
                button.firstChild.classList.remove("fa-moon");
                button.firstChild.classList.remove("fa-lightbulb");
                button.firstChild.classList.add("fa-moon");
                document.documentElement.setAttribute('data-theme', 'light');
            }
        } else {
            setTimeout(function() {
                update();
            }, 1000)
        }
    }

    function setup() {
        console.log("setup dark/light mode !")
        if (!mode) {
            mode = "dark";
            window.localStorage.setItem("otoroshi-dark-light-mode", mode);
        }
        update();
        registerClicks();
    }

    window.onload = function() {
        setTimeout(function() {
            setup();
        }, 1000)
    }
})()
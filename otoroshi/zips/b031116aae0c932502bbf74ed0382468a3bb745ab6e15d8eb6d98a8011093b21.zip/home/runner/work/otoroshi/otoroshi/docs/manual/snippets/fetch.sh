// #curl
curl -L -o otoroshi.jar 'https://github.com/MAIF/otoroshi/releases/download/v16.11.2/otoroshi.jar'
// #curl

// #wget
wget 'https://github.com/MAIF/otoroshi/releases/download/v16.11.2/otoroshi.jar'
// #wget
